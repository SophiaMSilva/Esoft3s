function nome(){
    document.getElementById("nomezin").value
    console.log(document.getElementById("nomezin").value)
 }

function senha(){
   document.getElementById("exampleInputPassword1").value
   console.log(document.getElementById("exampleInputPassword1").value)
}
//.getpessoa
let pessoa =[
    {'nome': 'maria,'} ]
console.log(pessoa)